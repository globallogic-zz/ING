/// <reference path="backbone.js" />
/// <reference path="underscore.js" />
/// <reference path="jquery/jquery-1.7.2.min.js" />

var INGDirectUI = INGDirectUI || {};

(function ($) {
    INGDirectUI.MenuItem = Backbone.Model.extend({});
})(jQuery);